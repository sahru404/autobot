import asyncio
import re
import time
from time import sleep
from userbot import CMD_HELP
from userbot.events import register

@register(outgoing=True, pattern='^.price(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("LIST HARGA **JEE AND BEE STORE**\n"
			 f"=========================\n"
			 f"WEB PHISING (1 BULAN)\n"
			 f"\n"
			 f"DOMAIN : 100.000 \n"
			 f"SUBDOMAIN : 20.000 \n"
			 f"*FREE CHECK TRACK DELIVERY\n"
			 f"=========================\n"
			 f"WHM\n"
			 f"\n"
			 f"MINI : 30.000\n"
			 f"MEDIUM : 40.000\n"
			 f"EXTRA : 50.000\n"
			 f"SUPER : 60.000\n"
			 f"=========================\n"
			 f"MWHM\n"
			 f"\n"
			 f"MINI : 80.000\n"
			 f"MEDIUM : 100.000\n"
			 f"EXTRA : 120.000\n"
			 f"SUPER : 150.000\n"
			 f"=========================\n"
			 f"LIVE RESULT\n"
			 f"\n"
			 f"50+ RESULT : 200.000\n"
			 f"99+ RESULT : 400.000\n"
			 f"=========================\n"
			 f"TWITTER\n"
			 f"\n"
			 f"50 RESULT : 200.000\n"
			 f"100 RESULT : 400.000\n"
			 f"=========================\n"
			 f"TWITTER\n"
			 f"\n"
			 f"1 AKUN : 5.000\n"
			 f"12 AKUN : 50.000\n"
			 f"=========================\n"
			 f"@JeeHeree")


@register(outgoing=True, pattern='^.unredflag(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("UNTUK DI INGAT SAJA\nBUAT YANG BLM TAU BERAPA LAMA PROSES UNREDFLAG ."
f"\n\nBIASANYA PALING CEPAT ADALAH 1 MALAM DAN PALING LAMA ADALAH 1 - 3 HARI\nTHANKS BOSQU")
	
@register(outgoing=True, pattern='^.1(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("Silahkan kirim email anda\n"
			 f"Dan request tampilan yang ingin anda gunakan\n"
			 f"List Tampilan : [Klik Disini](https://jefanya.com)")
	
@register(outgoing=True, pattern='^.2(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Ok beri waktu beberapa menit, saya akan membuat kan web phising sesuai dengan tampilan yang anda request`")
	

	
@register(outgoing=True, pattern='^.3(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("Website Phising telah dibuat\n\n"
			 f"Garansi : Full\n"
			 f"Note : `Garansi tidak akan habis sebelum durasi website telah habis, dan ketika durasi di perpanjang maka garansi akan ikut diperpanjang`\n"
			 f"Usahakan untuk komplain / menggunakan garansi maka sertakan ORDER ID\n"
			 f"Order ID ada di data phising, dan itu sangatlah berguna")

@register(outgoing=True, pattern='^.whm(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("Berikut Adalah List Harga dari **WHM** \n"
			 f"**Whm Mini**\n"
			 f"`Harga :` 40.000/1 Month\n"
			 f"`Create 15 cPanel`\n"
			 f"`10GB Web Space`\n"
			 f"`Unlimited Bandwith`\n"
			 f"`Free SSL Certificate`\n"
			 f"\n"
			 f"**Whm Medium**\n"
			 f"`Harga :` 50.000/1 Month\n"
			 f"`Create 25 cPanel`\n"
			 f"`15GB Web Space`\n"
			 f"`Unlimited Bandwith`\n"
			 f"`Free SSL Certificate`\n"
			 f"\n"
			 f"**Whm Extra**\n"
			 f"`Harga :` 60.000/1 Month\n"
			 f"`Create 40 cPanel`\n"
			 f"`20GB Web Space`\n"
			 f"`Unlimited Bandwith`\n"
			 f"`Free SSL Certificate`\n"
			 f"\n"
			 f"**Whm Super**\n"
			 f"`Harga :` 70.000/1 Month\n"
			 f"`Create 50 cPanel`\n"
			 f"`25GB Web Space`\n"
			 f"`Unlimited Bandwith`\n"
			 f"`Free SSL Certificate`\n"
			 f"Dukung saya dengan cara join di channel saya! [klik disini](http://t.me/Jejakcheat14)")
	
@register(outgoing=True, pattern='^.tam(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Tampilan cek di :` https://jeenoreal.com/")
	
@register(outgoing=True, pattern='^.proses(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("OK, Saya Akan Mengirimkan result dengan cara LIVE. Jadi nnti kalau sudah proses atau sudah giliranmu akan saya beritahu ~ Terimakasih \n"
			 f"Info Lebih Lanjut! [klik disini](http://t.me/Jejakcheat14)")

@register(outgoing=True, pattern='^.mwhm(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("Daftar harga **M.WHM**\n"
			 f"MINI : 80.000\n"
			 f"MEDIUM : 100.000\n"
			 f"EXTRA : 120.000\n"
			 f"SUPER : 150.000\n"
			 f"Info Lebih Lanjut! [klik disini](http://t.me/Jejakcheat14)")


@register(outgoing=True, pattern='^.full(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("Mohon Maaf, Untuk sekarang result live **FULL** \n"
			 f"Info Lebih Lanjut! [klik disini](http://t.me/Jejakcheat14)")


@register(outgoing=True, pattern='^.jual(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("OPEN WEBSITE PHISING\n"
			f"M.WHM, WHM, CPANEL\n"
			 f"\n\n`Send email lancar\nada SSL atau gembok ijo\nBisa request tampilan\nDan masih banyak lagi!!`\n\nHarga?\n\nDomain : Rp. 100.000 `Bisa Request Nama Web`\n"
			 f"Domain : Rp. 50.000 `Tidak bisa request nama web alias yang nentuin penjual`\n"
			 f"Subdomain : Rp. 20.000 `Tidak bisa request apapun kecuali request tampilan website`\n\n"
			 f"Payment via : BCA, OVO, TELKOMSEL\n"
			 f"Mau lihat tampilan web ? Yuk ke demo [klik di sini](https://senturypanel.com/)\n\n"
			 f"Chat ? [Jefanya Efandchris](http://t.me/Jejakcheat)\n"
			 f"Join channel telegram yuk! [klik disini](http://t.me/Jejakcheat14)")


@register(outgoing=True, pattern='^.demo(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Untuk melihat tampilan yang di inginkan\n Silahkan cek`\n [Disini](https://jefanya.com) \n#SenturyBot")


# Create by myself @JejakCheat

@register(outgoing=True, pattern='^.sibuk(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Sebentar Ya Gan`")
	sleep(2)
	await typew.edit("`Masih Ngecek`")
	sleep(1)
	await typew.edit("`Oh Ternyata Jefa Masih sibuk... Tunggu sebentar nanti akan dibaca \n#SenturyBot`")

# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.on(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Apaan anj baru on gw, gelut??` \n[#jnrstore](t.me/JeeHeree")
	
	# Create by myself @JejakCheat
	
# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.o(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Maaf baru online, ada apa bos?` \n#SenturyBot")
	
	# Create by myself @JejakCheat


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.perbedaan(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Saya jelaskan untuk perbedaan domain dan subdomain .\n\nDomain (pubg.com) **langsung tidak ada tambahan sama sekali\n\nSubdomain ( blablabla.pubg.com ) **ada Tambahan di depan domainnya .\n\nBot By : [#Jefanya](t.me/JejakCheat)")

# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.BRI(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`BRI : `091001051136538 `A/N RIZKY SEPTIAN CAHYA` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \nBot By : [#JefanyaBot](t.me/JejakCheat)")


	
# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.bca(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`BCA : `0901316839 `A/N PILU EFENDI` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \nBot By : [#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.tsel(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`TELKOMSEL : `082247870713 `A/N -` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \nBot By : [#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.bni(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`BNI : `0830301026 `A/N Jefanya Efandchris` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \nBot By : [#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.ovo(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`OVO : `082247870713 `A/N NI KETUT SUERTI` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \nBot By : [#JefanyaBot](t.me/JejakCheat)")

# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.DANA(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`DANA : `082210089492 `A/N RIZKY SEPTIAN CAHYA` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \nBot By : [#JefanyaBot](t.me/JejakCheat)")

# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.bcaj(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`BCA : `3030634780 `A/N Sutri nanda` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \n[#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.dana(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`DANA : `085156073629` A/N IDRUN NAFIS` \nSertakan Bukti Transfer Ya (Wajib) Untuk melanjutkan transaksi \nBot By : [#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.data(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`Kirim Email + Tampilan yang sudah di request di atas` (Sesuai nama di demo.senturypanel.xyz) \nBot By : [#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.harga(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`UPDATE HARGA HARI INI` \n\nDOMAIN : 100.000 (Bisa Request Nama Web)\nDOMAIN : 50.000 (Tidak bisa request nama web)\nSUBDOMAIN : 20.000 (SELAIN PULSA) \nSUBDOMAIN : 25.000 (Via Pulsa) \n\nBot By : [#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.bug(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("`JIKA ADA ERROR ATAU BUG DI TAMPILAN PHISING KALIAN TINGGAL SURUH TEMAN KALIAN UNTUK MEMBUKA WEB KALIAN ITU \n\nSyarat : \n1. BEDA HP \n2. BEDA SINYAL \n3. BELUM PERNAH BUKA WEB ITU`\nBot By : [#JefanyaBot](t.me/JejakCheat)")


# Create by myself @JejakCheat
@register(outgoing=True, pattern='^.exp(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(0)
	sleep(0)
	await typew.edit("**EXP TIME !!** \nMaaf bos, phising saya matikan atau saya alihkan ke `exp.senturypanel.xyz` \nDikarenakan Sudah melewati tanggal kadaluarsa \nDan jika mau perpanjang silahkan balas pesan ini  \n Dan jika tidak ingin perpanjang abaikan pesan ini \nBot By : [#JefanyaBot](t.me/JejakCheat14)")


# Create by myself @JejakCheat
CMD_HELP.update({
    "done":
    "`.domainanim` = `DOMAIN` PUBG Mobile Season 12 `Animation Version`\n"
    "`.domaintourney` = `DOMAIN` PUBG Mobile Season 12 `Tournament`\n"
    "`.subdomainanim` = `SUBDOMAIN` PUBG Mobile Season 12 `Animation Version`"
    "`.subdomaintourney` = `SUBDOMAIN` PUBG Mobile Season 12 `Tournament`"
    "`.subdomainbokep1` = `SUBDOMAIN` Facebok Bokep `V1`"
    
})

